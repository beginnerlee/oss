import random
import pandas as pd

df=pd.read_excel('./enword.xlsx')
lista=df['word']
listb=df['mean']
choicelist=random.randint(0,619)
word=lista[choicelist]
strlen=len(lista[choicelist])
print("지금부터 hangman 게임을 시작하겠습니다. 기회는 단어길이의 4배가 주어집니다.")

a=""
b=0

for i in range(strlen*4):#게입지속횟수
    b=1
    for w in word:
        if w in a:
            print(w,end=" ")
        else:
            print(end="_ ")
            b=0
            
    if b==1:
        print("축하합니다. 성공하셨습니다.")
        break
        
    ip=input("알파벳을 입력하시오.")
    
    if ip not in a:
        a+=ip
        
    if ip in word:
        print("있습니다.")
    else:
        print("없습니다.")
        
if b==0:
    print("실패하셨습니다.")